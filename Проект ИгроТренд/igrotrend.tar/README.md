# 🎮 ИгроТренд (IgroTrend)

**ИгроТренд** — современная социальная платформа для геймеров и энтузиастов искусственного интеллекта. Объединяет геймеров, киберспортивные команды, клубы по интересам и предоставляет уникальные возможности для общения и развития.

![Next.js](https://img.shields.io/badge/Next.js-16-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Prisma](https://img.shields.io/badge/Prisma-ORM-2D3748?style=flat-square&logo=prisma)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?style=flat-square&logo=tailwind-css)

## ✨ Возможности

### 🎯 Основной функционал
- **📰 Лента постов** — публикуйте статьи, делитесь новостями игры и AI
- **👥 Клубы** — создавайте сообщества по интересам
- **🏆 Киберспортивные команды** — формируйте команды для турниров (с модерацией)
- **💕 Дейтинг для геймеров** — находите тиммейтов и единомышленников (swipe-механика)
- **🔔 Система уведомлений** — будьте в курсе событий
- **⭐ Система уровней** — развивайте профиль и получайте награды

### 🌍 Мультиязычность
- 🇷🇺 Русский
- 🇰🇿 Қазақша (Казахский)
- 🇬🇧 English
- 🇧🇾 Беларуская

### 🎨 Современный дизайн
- Neon/cyberpunk эстетика с пурпурными акцентами
- Плавные анимации (Framer Motion)
- Адаптивный дизайн (mobile-first)
- Dark mode по умолчанию

### 🛡️ Безопасность
- JWT аутентификация
- Email верификация (опционально)
- Ролевая система (USER, ADMIN, DEVELOPER)
- Защищённый Dev Panel для разработчиков

## 🚀 Быстрый старт

### Требования
- Node.js 18+ или Bun
- SQLite (для разработки) / PostgreSQL / MySQL (для production)

### Установка

```bash
# Клонирование репозитория
git clone https://github.com/YOUR_USERNAME/igrotrend.git
cd igrotrend

# Установка зависимостей
bun install

# Настройка окружения
cp .env.example .env
# Отредактируйте .env!

# Инициализация базы данных
bun run db:push
bun run seed

# Запуск в режиме разработки
bun run dev
```

Откройте [http://localhost:3000](http://localhost:3000) в браузере.

### Аккаунт разработчика

После `bun run seed` будет создан аккаунт разработчика:

```
Email: dev@igrotrend.local
Password: (указана в seed.ts)
```

## 📁 Структура проекта

```
src/
├── app/
│   ├── api/              # API endpoints (auth, admin)
│   ├── layout.tsx        # Root layout
│   ├── page.tsx          # Main page
│   └── globals.css       # Global styles
├── components/
│   ├── admin/            # Dev Panel
│   ├── auth/             # Login/Register forms
│   ├── clubs/            # Clubs component
│   ├── dating/           # Dating with swipes
│   ├── feed/             # Posts feed
│   ├── layout/           # Header, Footer
│   ├── profile/          # User profile
│   ├── teams/            # Esports teams
│   └── ui/               # shadcn/ui components
├── hooks/                # Custom React hooks
├── lib/
│   ├── db.ts             # Prisma client
│   ├── i18n/             # Translations (4 languages)
│   └── utils.ts          # Utility functions
└── store/                # Zustand state management

prisma/
└── schema.prisma         # Database schema
```

## 🛠️ Технологии

### Frontend
- **Next.js 16** — App Router, Server Components
- **React 19** — UI библиотека
- **TypeScript 5** — типобезопасность
- **Tailwind CSS 4** — стилизация
- **shadcn/ui** — компоненты (Radix UI)
- **Framer Motion** — анимации
- **Zustand** — state management
- **Lucide React** — иконки

### Backend
- **Prisma ORM** — работа с БД
- **SQLite** — для разработки
- **JWT** — аутентификация
- **bcryptjs** — хеширование паролей

## 📜 Скрипты

```bash
bun run dev        # Запуск в режиме разработки
bun run build      # Production сборка
bun run start      # Запуск production сервера
bun run lint       # ESLint проверка
bun run db:push    # Синхронизация схемы Prisma с БД
bun run seed       # Создание тестовых данных
```

## 🌐 Деплой

Подробная инструкция в [DEPLOY.md](./DEPLOY.md)

### Быстрый деплой на Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/igrotrend)

1. Подключите репозиторий к Vercel
2. Добавьте environment variables:
   - `DATABASE_URL` — connection string от БД
   - `JWT_SECRET` — секретный ключ (минимум 64 символа!)
3. Deploy!

⚠️ **Важно:** SQLite не работает на Vercel. Используйте PlanetScale, Supabase или Vercel Postgres.

## 🔐 Переменные окружения

```env
# База данных
DATABASE_URL="file:./db/custom.db"

# JWT секрет (минимум 64 символа в production!)
JWT_SECRET="your-secret-key"

# URL приложения
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Email (опционально)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="your-email@gmail.com"
SMTP_PASS="your-app-password"
```

## 📊 Dev Panel

Панель разработчика доступна только для роли `DEVELOPER`:

- 📈 **Обзор** — статистика платформы
- 👥 **Пользователи** — управление аккаунтами
- 📝 **Контент** — модерация постов
- 🏆 **Команды** — одобрение киберспортивных команд
- 🛡️ **Клубы** — управление сообществами
- 🗄️ **База данных** — экспорт и управление
- ⚙️ **Настройки** — конфигурация платформы

## 🗺️ Roadmap

### v1.0 (MVP) ✅
- [x] Регистрация и авторизация
- [x] Профили пользователей
- [x] Лента постов
- [x] Клубы по интересам
- [x] Киберспортивные команды
- [x] Дейтинг для геймеров
- [x] Dev Panel
- [x] Мультиязычность (4 языка)

### v1.1
- [ ] PostgreSQL для production
- [ ] Реальные email уведомления
- [ ] Поиск по платформе
- [ ] Модерация контента
- [ ] Репорты и баны

### v2.0
- [ ] Мобильное приложение (React Native)
- [ ] Live streaming интеграция
- [ ] Турнирная система
- [ ] Монетизация
- [ ] AI модерация

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте ветку (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в ветку (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

MIT License — используйте свободно для личных и коммерческих проектов.

---

**Создано с ❤️ для игрового сообщества**

*Год: 2026*
